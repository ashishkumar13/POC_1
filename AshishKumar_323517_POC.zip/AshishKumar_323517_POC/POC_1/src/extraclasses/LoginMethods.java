package extraclasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginMethods {
	String actualResult;
	String expectedResult;
	WebDriver dr;
	
	public LoginMethods(WebDriver dr, String expectedResult) {
		this.dr = dr;
		this.expectedResult = expectedResult;
	}
	
	public String login(String email, String password) {
		
		actualResult = null;
		String actualResult2;
		
		
		WebElement emailField = dr.findElement(By.xpath("//*[@id=\"Email\"]"));
		WebElement passField = dr.findElement(By.xpath("//*[@id=\"Password\"]"));
													
		WebElement login = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"));
		emailField.sendKeys(email);
		passField.sendKeys(password);
		login.click();	
		boolean b1;
		
		try {
			
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
			if(b1) {
				actualResult += dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			WebElement proName = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
			actualResult2 = proName.getText();
			if(actualResult2.equals(expectedResult)) {
				actualResult = actualResult2;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}		
		
		return actualResult;
			
		
	}
	
}

package runnerpkg;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

// Finished and Running Fine

@CucumberOptions( features = "FEATURES", glue = "stepdefpkg")
public class NewTestRun extends AbstractTestNGCucumberTests {
	
}

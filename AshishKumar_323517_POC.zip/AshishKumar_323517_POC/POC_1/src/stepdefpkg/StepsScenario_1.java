package stepdefpkg;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import extraclasses.LoginMethods;

public class StepsScenario_1 {
	WebDriver dr;
	
	String email;
	String password;
	String expectedResult; 
	String actualResult ;
	
	LoginMethods lm;
	
	Logger log;
	

	
	@Given("^browser launched with url$")
	public void browser_launched_with_url() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();		
		dr.get("http://demowebshop.tricentis.com");	
		
		log = Logger.getLogger("devpinoyLogger");
		log.info("Browser Launch with URL: http://demowebshop.tricentis.com");
		
	}

	@Given("^login link is clicked$")
	public void login_link_is_clicked() throws Throwable {
	    dr.findElement(By.xpath("//a[text() = 'Log in']")).click();
	    
	}

	@When("^User login as valid email and password$")
	public void user_login_as_valid_email_and_password() throws Throwable {
		
		email = "luffy@anime.com";
		password = "asfzigg";
		expectedResult = "luffy@anime.com";
		
	    lm = new LoginMethods(dr, expectedResult);
	    log.info("Login with valid email:" + email + " and valid password: "+ password );
	    actualResult = lm.login(email, password);
	    
	    System.out.println(expectedResult);
	    System.out.println(actualResult);
	}

	@Then("^verify successfull login using profile name$")
	public void verify_successfull_login_using_profile_name() throws Throwable {
	    
		SoftAssert sa = new SoftAssert();
	    sa.assertEquals(actualResult, expectedResult);
	    
	    
	    log.info("Expected Result: " + expectedResult + "\nActual Result: "+ actualResult);
	    dr.quit();
	    
	}
	
	@When("^User login as invalid email and invalid password$")
	public void user_login_as_invalid_email_and_invalid_password() throws Throwable {
		
		email = "abc@xyz.com";
		password = "asfzigg";
		expectedResult = "Login was unsuccessful. Please correct the errors and try again.\n" + 
				"The credentials provided are incorrect";
	    lm = new LoginMethods(dr, expectedResult);
	    log.info("Login with invalid email:" + email + " and valid password: "+ password );
	    
	    actualResult = lm.login(email, password);
	    
	}

	@Then("^verify error message that appears$")
	public void verify_error_message_that_appears() throws Throwable {	    
		   
	    SoftAssert s1 = new SoftAssert();
	    s1.assertEquals(actualResult, expectedResult);
	    
	    
	    log.info("Expected Result: " + expectedResult + "\nActual Result: "+ actualResult);
	    dr.quit();
	    
	}

}
